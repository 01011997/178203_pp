package com.cg.bank.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountServiceImpl;
import com.cg.bank.service.IAccountService;

public class AccountMain {
	public static void main(String[] args) throws AccountException {
		Scanner scan=null;
		Scanner scan1=null;
		
		IAccountService service= new AccountServiceImpl();
		Account acc=null;
		String ContinueChoice="";
		do {
			System.out.println("Welcome to Bank App");	
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposite\n4.Withdraw\n5.Fund Transfer\n6.Print Transaction \n7:Exit");
		
			int choice =0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your Choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice) {
					case 1:
				             	String Username="";
									boolean UsernameFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter your name");
										try {
										Username=scan1.nextLine();
										service.validateUserName(Username);	
										UsernameFlag=true;
										break;
										}catch(AccountException e) {
											UsernameFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!UsernameFlag);
						
									String MobileNo="";
									boolean  MobileNoFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Mobile number");
										try {
											 MobileNo=scan1.nextLine();
										service.validateMobileNo(MobileNo);	
										 MobileNoFlag=true;
										break;
										}catch(AccountException e) {
											 MobileNoFlag=false;
											System.out.println(e.getMessage());
										}
									}while(! MobileNoFlag);
									
									int Balance=0;
									boolean  BalanceFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter the amount ");
										Balance=scan1.nextInt();

										 BalanceFlag=true;
										 break;
									}while(!  BalanceFlag);
									
									acc=new Account(Username,MobileNo, Balance);
									int Account_number=(int) (Math.random()*1000*1000);
									//account.setAccount_number(Account_number);
									System.out.println("Account created Successfully with Account number"+ Account_number);
									acc.setAccount_number(Account_number);
									
									service.addnewAccount(acc);
									break;
								case 2:
									int Accno = 0;
									boolean Account_numberFlag = false;
									do {
										scan = new Scanner(System.in);
										System.out.println("Enter Account number");
										try {
											Accno = scan.nextInt();
											service.validateAccount_number(Accno);						
											Account_numberFlag = true;
											break;

										} catch (InputMismatchException e) {
											Account_numberFlag = false;
											System.err.println(e.getMessage());
										} catch (AccountException e) {
											System.err.println(e.getMessage());
										}

									} while (!Account_numberFlag);
									service.ShowBalance(Accno);
									service.showwalletbal(Accno);
									System.out.println(service.ShowBalance(Accno));
									System.out.println(service.showwalletbal(Accno));
									break;
								
								case 3:
									//For Deposit
									System.out.println("Enter Account Number..");
									int Accnum=scan.nextInt();
									System.out.println("Enter the amount for deposit");
									int amount=scan.nextInt();
									double amountAfterDeposite=service.deposite(Accnum,amount);
									System.out.println("New Balance: "+amountAfterDeposite);
									break;
								case 4:
									//For Deposit
									System.out.println(" Enter your account number");
									int Account_num=scan.nextInt();
									System.out.println(" Enter the amount you want to withdraw");
									double amountwithdraw=scan.nextDouble();
									double amountAfterDeposite1=service.withdraw(Account_num,amountwithdraw);
									System.out.println("New Balance: "+amountAfterDeposite1);
									break;	
									
									
								case 5:
									
									//Fund Transfer
									
									System.out.println("1.Account to wallet\n2.wallet to account\n3.Wallet to wallet");
									int ch=0;
									ch=scan.nextInt();
									switch(ch) {
									
									
									case 1:
										System.out.println("Enter Account No");
										int accno=scan.nextInt();
										System.out.println("Enter amount to be transferrred to wallet");
										int amt=scan.nextInt();
										String str=service.accounttowallet(accno,amt);
										System.out.println(str);
										break;
									case 2:
										
										System.out.println("Enter Account No");
										int acn0=scan.nextInt();
										System.out.println("Enter amount to be transferrred to Account");
										int amtt=scan.nextInt();
										String st=service.wallettoaccount(acn0,amtt);
										System.out.println(st);
										break;
										
										
								
										
									case 3:
									int account_number,reciever_account_number;
									System.out.println("Enter Your Account Number: ");
									account_number=scan.nextInt();
									System.out.println("Enter Receiver Account Number: ");
									reciever_account_number=scan.nextInt();
									System.out.println("Enter Amount to Transfer: ");
									amount=scan.nextInt();
									String s=service.fundTransfer(account_number,reciever_account_number,amount);
									System.out.println(s);
									break;
									}
									break;
									
								case 6:
									System.out.println("Enter the account number");
									int account_number=scan.nextInt();
									List<Transaction> l=service.printtransaction(account_number);
									l.stream().forEach(System.out::println);
							
									break;
												
								case 7:
									System.out.println("Thank you for banking with us!!!");
									System.exit(0);
									
									break;
									}
								
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.err.println("Please Enter digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
		scan1.close();
		
	}
}




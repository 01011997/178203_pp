package com.cg.bank.dao;

import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	int ShowBalance(int account_number1) throws AccountException ;

	double deposite(int Account_number11, double amount) throws AccountException;

	double withdraw(int account_number111, double amountwithdraw) throws AccountException;
	public void addnewAccount(Account a);

	String fundTransfer(int account_number, int reciever_account_number, double amount);

	List<Transaction> printtransaction(int account_number);

	String accounttowallet(int accno, int amt);

	String wallettoaccount(int acn0, int amtt);

	Object showwalletbal(int accno);



}

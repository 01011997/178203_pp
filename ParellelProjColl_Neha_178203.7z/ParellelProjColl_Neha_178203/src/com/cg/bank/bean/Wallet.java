package com.cg.bank.bean;

public class Wallet {
private int account_no;
private int wallbal;
@Override
public String toString() {
	return "wallet [account_no=" + account_no + ", wallbal=" + wallbal + "]";
}
public Wallet(int account_no, int wallbal) {
	super();
	this.account_no = account_no;
	this.wallbal = wallbal;
}
public int getAccount_no() {
	return account_no;
}
public void setAccount_no(int account_no) {
	this.account_no = account_no;
}
public int getWallbal() {
	return wallbal;
}
public void setWallbal(int amountAfterDeposite) {
	this.wallbal = amountAfterDeposite;
}

}

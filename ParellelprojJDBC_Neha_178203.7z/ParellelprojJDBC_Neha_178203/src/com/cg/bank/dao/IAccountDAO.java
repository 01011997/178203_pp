package com.cg.bank.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	int ShowBalance(int account_number1) throws  SQLException ;

	double deposite(int Account_number11, double amount) throws  SQLException;

	double withdraw(int account_number111, double amountwithdraw) throws SQLException;
	public int addnewAccount(Account a) throws SQLException;

	String fundTransfer(int account_number, int reciever_account_number, double amount) throws SQLException;

	List<Transaction> printtransaction(int account_number);

	String accounttowallet(int accno, int amt) throws SQLException;

	String wallettoaccount(int acn0, int amtt) throws SQLException;

	Object showwalletbal(int accno) throws SQLException;



}

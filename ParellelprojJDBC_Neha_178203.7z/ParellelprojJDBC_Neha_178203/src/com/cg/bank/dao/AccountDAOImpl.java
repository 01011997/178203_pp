package com.cg.bank.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;



public class AccountDAOImpl implements IAccountDAO {

		static Connection c;
		public AccountDAOImpl() {
				try {
					Class.forName("oracle.jdbc.OracleDriver");
					if(c==null)
					{
						c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
						System.out.println("Connected"+ c);
					}

					}catch(Exception e)
					{
					System.out.println(e);
					}
		}

	@Override
	public int ShowBalance(int account_number1) throws SQLException {
		PreparedStatement ps=c.prepareStatement("Select balance from Account where account_number=?");

		ps.setInt(1, account_number1);

		ResultSet rs=ps.executeQuery();

		if(rs.next())

		return rs.getInt(1);

		else return -1;

	}

	@Override
	public double deposite(int Account_number11, double amount) throws  SQLException {

PreparedStatement ps=c.prepareStatement("update account set balance=balance+? where account_number=?");



	ps.setDouble(1, amount);

	ps.setInt(2, Account_number11);

	ps.executeQuery();

		return amount;
	}

	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws SQLException {
		 PreparedStatement ps=c.prepareStatement("update account set balance=balance-? where account_number=?");

		 	ps.setDouble(1, amountwithdraw);

		 	ps.setInt(2, account_number111);

		 	ps.executeQuery();

			return amountwithdraw;
	}

	@Override
	public int addnewAccount(Account a) throws SQLException {

		PreparedStatement pst=c.prepareStatement("insert into Account values(?,?,?,?,?,?)");

		pst.setInt(1, a.getAccount_number());

		pst.setString(2, a.getUsername());

		pst.setString(3, a.getMobileNo());
		pst.setDouble(5,0);

		pst.setDouble(6,0);

		pst.executeQuery();

		PreparedStatement ps1=c.prepareStatement("Select Account_number from Account where account_number=?");

		ps1.setInt(1, a.getAccount_number());

		ResultSet rs=ps1.executeQuery();

		if(rs.next())

			return rs.getInt(1);

		else

			return (Integer)null;
		}
		
	

	@Override
	public String fundTransfer(int account_number, int reciever_account_number, double amount) throws SQLException {
		PreparedStatement ps=c.prepareStatement("update account set wallet_balance=wallet_balance-? where account_number=?");

	ps.setDouble(1, amount);

			ps.setInt(2, account_number);

			ps.executeQuery();

			ps=c.prepareStatement("update account set wallet_balance=wallet_balance+? where account_number=?");

			ps.setDouble(1, amount);

			ps.setInt(2, reciever_account_number);

			ps.executeQuery();

			return "Transferred";
	}

	@Override
	public List<Transaction> printtransaction(int account_number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accounttowallet(int accno, int amt) throws SQLException {
		PreparedStatement ps=c.prepareStatement("update account set balance=balance-? where account_number=?");


ps.setDouble(1, amt);

		ps.setInt(2, accno);

		ps.executeQuery();

		ps=c.prepareStatement("update account set wallet_balance=wallet_balance+? where account_number=?");

		ps.setDouble(1, amt);

		ps.setInt(2, accno);

		ps.executeQuery();

		return "Transferred";
	}

	@Override
	public String wallettoaccount(int acn0, int amtt) throws SQLException {
		PreparedStatement ps=c.prepareStatement("update account set balance=balance+? where account_number=?");

		ps.setDouble(1, amtt);

	ps.setInt(2, acn0);

		ps.executeQuery();
		ps=c.prepareStatement("update account set wallet_balance=wallet_balance-? where account_number=?");

		ps.setDouble(1, amtt);

			ps.setInt(2, acn0);

			ps.executeQuery();

			return "Transferred";
	}

	@Override
	public Object showwalletbal(int accno) throws SQLException {

		PreparedStatement ps=c.prepareStatement("Select wallet_balance from Account where account_number=?");

		ps.setInt(1, accno);

		ResultSet rs=ps.executeQuery();

		if(rs.next())

			return rs.getDouble(1);

		return rs.getDouble(1);
	}
}
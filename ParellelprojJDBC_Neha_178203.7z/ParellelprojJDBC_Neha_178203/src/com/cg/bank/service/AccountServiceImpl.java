package com.cg.bank.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.dao.IAccountDAO;
import com.cg.bank.exception.AccountException;


public class AccountServiceImpl implements IAccountService {
	IAccountDAO dao=new AccountDAOImpl();

	@Override
	public void validateUserName(String username) throws AccountException {
		String NameRegex="[A-Z]{1}[a-z]{2,8}";
		if(Pattern.matches(NameRegex, username)==false) {
		throw new AccountException("Username start with capital letter");	
	}
	}

	@Override
	public void validatePassword(String password) throws AccountException {
		String PasswordRegex="[0-9]{5}";
		if(Pattern.matches(PasswordRegex, password)==false) {
		throw new AccountException("Password contains 5 digits");		
	}
	}

	@Override
	public void validateMobileNo(String mobileNo) throws AccountException {
		String MobileRegex="[9|8|7]{1}[0-9]{9}";
		if(Pattern.matches(MobileRegex, mobileNo)==false) {
		throw new AccountException("Mobile number should contains 10 digits");
		
	}

	}

	@Override
	public void validateAccount_number(int account_number) throws AccountException {
		String AccountRegEx = "[0-9]+";
		if (Pattern.matches(AccountRegEx, String.valueOf(account_number)) == false) {
			throw new AccountException("orderid should contain only digits");
		}	
	}
	public void addnewAccount(Account a) throws SQLException{
	dao.addnewAccount(a);
		
	}

	public int ShowBalance(int account_number1) throws SQLException {
		return  dao.ShowBalance(account_number1);
		
	}
	@Override
	public double deposite(int Account_number11, double amount) throws SQLException {
		// TODO Auto-generated method stub
		return dao.deposite(Account_number11,amount);
	}
	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws SQLException {
		// TODO Auto-generated method stub
		return dao.withdraw(account_number111,amountwithdraw);
	}

	@Override
	public String fundTransfer(int account_number, int reciever_account_number, double amount) throws SQLException {
		// TODO Auto-generated method stub
		return dao.fundTransfer( account_number,reciever_account_number, amount);
	}

	@Override
	public List<Transaction> printtransaction(int account_number) {
		// TODO Auto-generated method stub
		return dao.printtransaction( account_number);
	}

	@Override
	public String accounttowallet(int accno, int amt) throws SQLException {
		// TODO Auto-generated method stub
		return dao.accounttowallet( accno,  amt);
	}

	@Override
	public String wallettoaccount(int acn0, int amtt) throws SQLException {
		// TODO Auto-generated method stub
		return dao.wallettoaccount( acn0,  amtt);
	}

	@Override
	public Object showwalletbal(int accno) throws SQLException {
		// TODO Auto-generated method stub
		return dao.showwalletbal(accno);
	}

	
	


	}

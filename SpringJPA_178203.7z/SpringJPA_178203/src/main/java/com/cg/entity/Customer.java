package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="custJPA")
@Component
public class Customer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String custName;
	@Id
	private String aadharno;
	private int acNo;
	private double acBal;
	private String cstmrMblNo;
	
	public Customer(String custName, String mobNo, int accNo, double balc, String address) {
		super();
		this.custName = custName;
		this.aadharno = mobNo;
		this.acNo = accNo;
		this.acBal = balc;
		this.cstmrMblNo = address;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getBalc() {
		return acBal;
	}
	public void setBalc(double balc) {
		this.acBal = balc;
	}
	public String getAddress() {
		return cstmrMblNo;
	}
	public void setAddress(String address) {
		this.cstmrMblNo = address;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMobNo() {
		return aadharno;
	}
	public void setMobNo(String mobNo) {
		this.aadharno = mobNo;
	}
	public int getAccNo() {
		return acNo;
	}
	public void setAccNo(int d) {
		this.acNo = d;
	}
	
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", mobNo=" + aadharno + ", accNo=" + acNo + ", balc=" + acBal
				+ ", address=" + cstmrMblNo + "]";
	}
	
	
}
